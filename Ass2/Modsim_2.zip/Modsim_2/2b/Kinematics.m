function [ state_dot ] = Kinematics( t, state, parameters )
    omega_scew = [0 -parameters(3) parameters(2); parameters(3) 0 -parameters(1); -parameters(2) parameters(1) 0];
    R_dot = reshape(state, [3,3])*omega_scew;
    state_dot = reshape(R_dot, 9, 1);
end
