R_1 = [0 1 0; 1 0 0; 0 0 -1];
R_2 = [5/13 0 -12/13; 0 1 0; 12/13 0 5/13];


[angle_1, k_1] = Sheppard(R_1);
[angle_2, k_2] = Sheppard(R_2);

display(k_1);
display(angle_1);
display(k_2);
display(angle_2);

function [angle, k] = Sheppard(R)
    k = null(R - eye(3));
    angle = acos((R(1,1)-k(1)^2)/(1-k(1)^2));
    
end
